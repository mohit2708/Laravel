<?php echo e($slot); ?>

<?php /**PATH D:\xampp_7.3\htdocs\chetu\authlaravel\blog\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>