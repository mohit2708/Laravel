<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\xampp_7.3\htdocs\chetu\authlaravel\blog\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>