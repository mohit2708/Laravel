<?php

namespace App\Http\Middleware;

use Closure;
use Session;
use Redirect;
use Auth;

class AccessControl
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {	
		//is(Session::has('admis')){
	//		return Redirect::to('/home');
		//}
	//	else{
		//	return $next($request);
	//	}
		if(Auth::user()->usertype == 'admin')
        {
            return $next($request);
        }
        else
        {
            return redirect('/home')->with('status','You are not Login to AdminPanel');
        }
    }
}
