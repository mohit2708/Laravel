<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Hash;
use Auth;

class RegisterController extends Controller
{

	public function register()
	{
		return view('auth.signup');
	}
	public function doRegister(Request $request)
	{
      $request->validate([
          'name' => 'required|string|max:255',
          'email' => 'required|string|email|max:255|unique:users',
         // 'password' => 'required|string|min:8|confirmed',
		 //'password' => 'required|min:6|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/'
		  'password' => [
            'required',
            'string',
            'min:8',             // must be at least 8 characters in length
			'confirmed',
            'regex:/[a-z]/',      // must contain at least one lowercase letter
            'regex:/[A-Z]/',      // must contain at least one uppercase letter
            'regex:/[0-9]/',      // must contain at least one digit
            'regex:/[@$!%*#?&]/', // must contain a special character
        ],
          'password_confirmation' => 'required',
      ],
	  [
		'password.regex' => 'Password must contain at least one number and one uppercase and lowercase letters and one special characters.',
	  ]
	  
	  );
	  
	  

      User::create([
          'name' => $request->name,
          'email' => $request->email,
          'password' => Hash::make($request->password),
      ]);

      return redirect('login');
	}
	
	
	public function login()
	{
		return view('auth.login');
	}
	public function doLogin(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
        ]);

        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            return redirect()->intended('home');
        }

        return redirect('login')->with('error', 'Oppes! You have entered invalid credentials');
    }
	public function logout() {
		Auth::logout();

		return redirect('login');
	}
	
}
