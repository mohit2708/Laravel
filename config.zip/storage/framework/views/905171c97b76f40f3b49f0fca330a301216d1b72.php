<h1>Hi, <?php echo e($name); ?></h1>
<p>Thanks for the Subscription.<br>
Please Click the Below Link for Completing your profile.
</p>
<p>
    <a href="<?php echo e(url('/login')); ?>">Complete Application</a>
</p><?php /**PATH C:\xampp\htdocs\mohit\911inform\resources\views/mail.blade.php ENDPATH**/ ?>