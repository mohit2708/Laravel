
<?php $__env->startSection('content'); ?>
<div class="container-xl">
      <div class="table-responsive">
         <div class="table-wrapper">
            <div class="table-title">
               <div class="row">
                  <div class="col-sm-6">
                     <h2>Device <b>Information</b></h2>
                  </div>
               </div>
            </div>
<table class="table table-hover" id="device_info">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Device Serial</th>
      <th scope="col">Tunnel IP</th>
      <th scope="col">Destination</th>
      <th scope="col">Gateway</th>
      <th scope="col">Genmask</th>
    </tr>
  </thead>
  <tbody>
    <?php $no = 1; ?>
    <?php $__currentLoopData = $deviceinfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deviceinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($no++); ?></th>
      <td><?php echo e($deviceinfo->device_serial); ?></td>
      <td><?php echo e($deviceinfo->tunnel_ip); ?></td>      
      <td><?php echo e($deviceinfo->destination); ?></td>      
      <td><?php echo e($deviceinfo->gateway); ?></td>      
      <td><?php echo e($deviceinfo->genmask); ?></td>            
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
  </tbody>
</table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_7.3\htdocs\chetu\911inform\resources\views/device_info.blade.php ENDPATH**/ ?>