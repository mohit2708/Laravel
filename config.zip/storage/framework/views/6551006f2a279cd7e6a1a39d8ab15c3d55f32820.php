<h1>Hi, <?php echo e($name); ?></h1>
Activate
<p>
    <a href="<?php echo e(url('/login')); ?>">Complete Application1111111111</a>
</p><?php /**PATH C:\xampp\htdocs\mohit\911inform\resources\views/mailactive.blade.php ENDPATH**/ ?>