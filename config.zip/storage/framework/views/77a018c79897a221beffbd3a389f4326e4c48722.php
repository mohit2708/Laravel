
<?php $__env->startSection('content'); ?>
<body>
   <div class="container-xl">
      <div class="table-responsive">
         <div class="table-wrapper">
            <div class="table-title">
               <div class="row">
                  <div class="col-sm-6">
                     <h2>User <b>List</b></h2>
                  </div>
               </div>
            </div>
            <table class="table table-striped table-hover">
               <thead>
                  <tr>
                     <th>Name</th>
                     <th>Email</th>
                     <th>Date</th>
                     <th>Status</th>
                     <!-- <th>Actions</th> -->
                  </tr>
               </thead>
               <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td><?php echo e(ucfirst($user->name)); ?></td>
                     <td><?php echo e($user->email); ?></td>
                     <td><?php echo e(date('F d, Y', strtotime($user->created_at))); ?></td>
                     <td><input data-id="<?php echo e($user->id); ?>" class="toggle-class" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive" <?php echo e($user->status ? 'checked' : ''); ?>></td>
                     <!-- <td>                    
                        <a onclick="confirm_delete(<?php echo e($user->id); ?>);" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
                     </td> -->
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
               </tbody>
            </table>
            <div class="clearfix">           
               <?php echo $users->links(); ?>             
            </div>
         </div>
      </div>
   </div>
   <div class="modal fade" id="practice_modal">
      <div class="modal-dialog">
         <form id="companydata">
         <div class="modal-content">
            <input type="hidden" id="color_id" name="color_id" value="">
            <div class="modal-body">
               <input type="text" name="name" id="name" value="" class="form-control">
            </div>
            <input type="submit" value="Submit" id="submit" class="btn btn-sm btn-outline-danger py-0" style="font-size: 0.8em;">
         </div>
      </div>
   </div>
   <!-- Delete Modal HTML -->
   <div id="delete_confirm" class="modal fade" role="dialog">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <h4 class="modal-title">Delete User</h4>
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
               <p>Are you sure you want to delete these Records?</p>
            </div>
            <div class="modal-footer">
               <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
               <span id="delete_butt_id"></span>
            </div>
         </div>
      </div>
   </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_7.3\htdocs\chetu\authlaravel\blog\resources\views/admin_dashboard.blade.php ENDPATH**/ ?>