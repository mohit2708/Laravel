@extends('layouts.app')
@section('content')
<div class="container-xl">
      <div class="table-responsive">
         <div class="table-wrapper">
            <div class="table-title">
               <div class="row">
                  <div class="col-sm-6">
                     <h2>Route <b>List</b></h2>
                  </div>
                  <div class="col-sm-6"> 
                  <form class="form-inline my-2 my-lg-0" action="{{url('route-list')}}" method="GET">
                    <input class="form-control" type="search" name="q" placeholder="Search">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="{{url('route-list')}}"><button type="button" class="btn btn-secondary">Reset</button></a>
                </form>                     
                  </div>
               </div>
            </div>
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Device Serial</th>      
      <th scope="col">Destination</th>
      <th scope="col">Gateway</th>
      <th scope="col">Genmask</th>
      <th scope="col">Flags</th>
      <th scope="col">Metric</th>
      <th scope="col">Ref</th>
      <th scope="col">T Use</th>
      <th scope="col">I Face</th>
    </tr>
  </thead>
  <tbody>
    @php $no = 1; @endphp
    @foreach($roulelists as $roulelist)
    
    <tr>
      <th scope="row">{{ $no++ }}</th>
      <td>{{$roulelist->device_serial}}</td>            
      <td>{{$roulelist->destination}}</td>      
      <td>{{$roulelist->gateway}}</td>      
      <td>{{$roulelist->genmask}}</td>    
      <td>{{$roulelist->flags}}</td>  
      <td>{{$roulelist->metric}}</td>   
      <td>{{$roulelist->ref}}</td>
      <td>{{$roulelist->t_use}}</td>
      <td>{{$roulelist->iface}}</td> 
      <!-- <td><a onclick="confirm_delete({{$roulelist->id}});">Delete</a></td>           -->
    </tr>
      
    @endforeach   
  </tbody>
</table>
</div>
</div>
</div>
<!-- Delete Modal HTML -->
  <div id="delete_confirm" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">         
        <div class="modal-header">            
          <h4 class="modal-title">Delete User</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">          
          <p>Are you sure you want to delete these Records?</p>         
        </div>
        <div class="modal-footer">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <span id="delete_butt_id"></span>
        </div>      
    </div>
  </div>
</div>
@endsection