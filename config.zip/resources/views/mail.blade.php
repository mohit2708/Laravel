<h1>Hi, {{ $name }}</h1>
<p>Thanks for the Subscription.<br>
Please Click the Below Link for Completing your profile.
</p>
<p>
    <a href="{{ url('/login') }}">Complete Application</a>
</p>