<h1>Hi, {{ $name }}</h1>
Activate
<p>
    <a href="{{ url('/login') }}">Complete Application1111111111</a>
</p>