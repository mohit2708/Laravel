@extends('layouts.app')
@section('content')
<div class="container-xl">
      <div class="table-responsive">
         <div class="table-wrapper">
            <div class="table-title">
               <div class="row">
                  <div class="col-sm-6">
                     <h2>Device <b>Information</b></h2>
                  </div>
               </div>
            </div>
<table class="table table-hover" id="device_info">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Device Serial</th>
      <th scope="col">Tunnel IP</th>
      <th scope="col">Destination</th>
      <th scope="col">Gateway</th>
      <th scope="col">Genmask</th>
    </tr>
  </thead>
  <tbody>
    @php $no = 1; @endphp
    @foreach($deviceinfos as $deviceinfo)
    <tr>
      <th scope="row">{{ $no++ }}</th>
      <td>{{$deviceinfo->device_serial}}</td>
      <td>{{$deviceinfo->tunnel_ip}}</td>      
      <td>{{$deviceinfo->destination}}</td>      
      <td>{{$deviceinfo->gateway}}</td>      
      <td>{{$deviceinfo->genmask}}</td>            
    </tr>
    @endforeach   
  </tbody>
</table>
</div>
</div>
</div>
@endsection