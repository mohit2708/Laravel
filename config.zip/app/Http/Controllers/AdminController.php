<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\Mail\VerifyEmail;
use Mail;
use DB;

class AdminController extends Controller
{	
	public function __construct()
	{
		$this->middleware('auth');
	}
    public function adminDashboard(Request $request)
	{
		$users = User::where('id', '!=', 1)->paginate(10);
		return view('admin_dashboard', compact('users'));
	}
	public function status(Request $request){		
		$post = User::find($request->id);
		if($post->status == 1){
			$changestatus = 0;
			$rolechange = 'NULL';	
		}else{
			$changestatus = 1;
			$rolechange = 'admin';
		}
		$post->status = $changestatus;
		$post->role_type = $rolechange;
		$post->save();

		if($post->status == 1){
			$data = array('name'=>"Admin");   
              Mail::send(['text'=>'mailactive'], $data, function($message) {
                 $message->to('mksaxena27@gmail.com', 'Tutorials Point')->subject
                    ('Laravel Basic Testing Mail');
                 $message->from('ashish28saxena@gmail.com','Virat Gandhi');
              });

		}else{
			$data = array('name'=>"Admin");   
              Mail::send(['text'=>'maildeactivate'], $data, function($message) {
                 $message->to('mksaxena27@gmail.com', 'Tutorials Point')->subject
                    ('Laravel Basic Testing Mail');
                 $message->from('ashish28saxena@gmail.com','Virat Gandhi');
              });
			
		}

	}

	public function getUserData(Request $request)
    {
        $users = User::findorFail($request['id']);
        return $users;
	}   

	public function delete($id){		
			User::where('id', $id)->delete();	
			return redirect('admin-dashboard')->with('success', 'Service deleted successfully!');	
		
	}	
}
