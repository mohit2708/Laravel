<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use DB;

class AdminController extends Controller
{	
	public function __construct()
	{
		$this->middleware('auth');
	}
    public function adminDashboard(Request $request)
	{
		$users = User::where('id', '!=', 1)->paginate(10);
		return view('admin_dashboard', compact('users'));
	}
	public function status(Request $request){		
		$post = User::find($request->id);
		if($post->status == 1){
			$changestatus = 0;
		}else{
			$changestatus = 1;
		}
		$post->status = $changestatus;
		$post->save();		
	}

	public function getUserData(Request $request)
    {
        $users = User::findorFail($request['id']);
        return $users;
	}   

	public function delete($id){		
			User::where('id', $id)->delete();	
			return redirect('admin-dashboard')->with('success', 'Service deleted successfully!');	
		
	}	
}
