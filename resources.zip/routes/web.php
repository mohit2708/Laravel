<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('mynotes', function () {
//     return view('register');
// });

// ***************** Auth ******************* //
Route::get('/', 'LoginController@index');
Route::get('register', 'RegisterController@index');

// ***************** Crud ******************* //
Route::get('admin/crud', 'admin\crud\CrudController@index');
Route::get('admin/crud/add', 'admin\crud\CrudController@add');
Route::post('admin/crud/store', 'admin\crud\CrudController@store');
Route::get('admin/crud/edit/{id}', 'admin\crud\CrudController@edit');
Route::post('admin/crud/update/{id}', 'admin\crud\CrudController@update');
Route::get('admin/crud/delete/{id}', 'admin\crud\CrudController@delete');

// ***************** Ajax Country City ******************* //
Route::post('admin/ajax', 'admin\crud\CrudController@ajaxCity');
Route::get('admin/ajaxview', 'admin\crud\CrudController@ajaxview');

// ***************** Admin ******************* //
Route::get('admin', 'admin\AdminController@index');
Route::get('index2', 'admin\AdminController@index2');
Route::get('blanck', 'admin\AdminController@blanck');

Route::get('wordpress', 'admin\WordpressController@index');
// ***************** Website ******************* //
Route::get('mynotes', 'front\FrontController@index');