<?php
namespace App;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
class Crud extends Authenticatable{
    
    protected $table = 'user';
    protected $primarykey = 'id';
   
}
