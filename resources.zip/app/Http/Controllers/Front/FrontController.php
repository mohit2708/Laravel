<?php

namespace App\Http\Controllers\front;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class FrontController extends Controller
{
    public function index()
    {
    	#die('mohit');
    	return view('front/index');
    }
}
