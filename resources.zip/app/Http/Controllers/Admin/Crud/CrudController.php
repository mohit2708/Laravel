<?php

namespace App\Http\Controllers\admin\crud;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Crud; //call model
use Helper; 
use DB;

class CrudController extends Controller
{
    public function index(Request $request)
    {    

    	$search = $request->get('search');
    
		
            $cruddata = Crud::select('user.*');
				if($search){
					$cruddata->where('first_name', 'like', '%'.$search.'%');
					//$phpintques->orwhere('last_name', 'like', '%'.$search.'%');
				}
			$cruddata = $cruddata->orderBy('id', 'desc')
									->paginate(10);
			
            return view('admin/crud/index', compact('cruddata'));   


            //******* Use Db
        // $cruddata = DB::select('select * from user');
        // return view('admin/crud/index',['crud'=>$cruddata]);
            // ****end
        // $phpintques = PhpInterviewQuestion::select('php_interview_questions.*')->paginate(10);     
        //return view('admin.interview_questions.php.index')->with(['phpData'=>$phpintques]);
        //return view('admin.interview_questions.php.index', compact('phpintques'));
        
    }
    public function add()
    {
    	return view('admin/crud/add');
    }
    public function store(Request $request)
    {

    	try{
    	 DB::beginTransaction();

            $crud               = new Crud;
            $crud->first_name 	= $request->first_name;
            $crud->last_name    = $request->last_name;         
            $crud->save();

            // $interviewCategory                              = new InterviewCategory;
            // $interviewCategory->interview_questions_id      = $crud->id;
            // $interviewCategory->category_name               = $request->category;
            // $interviewCategory->save();           

            DB::commit();
            return redirect('admin/crud')->with('success', ' added successfully');

        }catch(\Illuminate\Database\QueryException $ex){
        		DB::rollback();
            return redirect()->back()->with('error', $ex->errorInfo[2])->withInput();
        }catch(\Exception $e){
            DB::rollback();
            return redirect()->back()->with('error', 'Error occurs! Please try again!');
        }
    }

    public function edit($id)
    {
    	$crud = Crud::where('id', $id)->first();
		return view('admin/crud/edit', compact('crud'));    	
    }

    public function update(Request $request, $id){      
            
            try{
                
                DB::beginTransaction();

                $crud              = Crud::find($id);
                $crud->first_name  = $request->first_name;
                $crud->last_name   = $request->last_name;
                $crud->save();
                
             DB::commit();
            return redirect('admin/crud')->with('success', 'Crud updated successfully');

            }catch(\Exception $e){
                 DB::rollback();
                return redirect()->back()->with('error', 'Error occurs! Please try again!');
            }
        }

    public function delete($id){
		
		 try{
			Crud::where('id', $id)->delete();	
			return redirect('admin/crud')->with('success', 'Crud deleted successfully!');	
		}
		catch (\Exception $ex) {
            return redirect()->back()->with('error', 'Error occurs! Please try again!');
        }
	}

	public function ajaxview()
	{
		return view('admin/ajax/index');
	}

	public function ajaxCity(Request $request){
		
		$input = $request->all();
		
		if(!empty($input)){
			
			$countryID = $request->get('id');
			
			$data = State::select('id', 'name')
						->where('country_id', $countryID)
						->orderBy('name', 'asc')
						->get();
			
			return json_encode($data);
			
		}
		
	}
    
}
