<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class WordpressController extends Controller
{
    public function index()
    {
    	#die('mohit');
    	return view('admin/wordpress/index');
    }
   
}
