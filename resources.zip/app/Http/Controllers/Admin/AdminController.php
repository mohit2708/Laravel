<?php

namespace App\Http\Controllers\admin;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
    	#die('mohit');
    	return view('admin/index');
    }
    public function index2()
    {    	
    	return view('admin/index2');
    }
    public function blanck()
    {    	
    	return view('admin/blanck');
    }
}
