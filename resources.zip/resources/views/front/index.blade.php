<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mynotes</title>    
     <link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}">
</head>
<body>
    <nav>
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="head-left">
                        <ul class="clearfix"> 
                            <li>Call us <a href="tel: +91 011-43073123">+91 011-43073123 </a> for Instant Tech Support NOW </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 clearfix">
                    <div class="quick-links">
                        <ul class="pull-right">
                            <li> <a href="#"> Home </a></li>
                            <li> <a href="#"> Our Clients </a></li>
                            <li> <a href="#"> Testimonials </a></li>
                            <li> <a href="#"> Contact Us </a></li>
                        </ul> 
                    </div>
                </div>
            </div>
        </div>
    </nav>
  
    <script src="js/main.js"></script>
</body>
</html>
